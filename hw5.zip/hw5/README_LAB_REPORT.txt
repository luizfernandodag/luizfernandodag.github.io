Lab5 - Readme

Student: Luiz Fernando de Andrade Gadelha
Id:      610800

Trouble 1: 

Begin time: 15:10
Description:Install lifeReload pluggin on intellij to reload the html page automatically
Solution: 1) File/Settings/Tools -> WebBrowser chose webbrowser 
	  2) File/Settings/Debugger/Live Edit -> choose time period to update the html page
          3) Chrome -> Download intellij extension
          4) Start html file with debugger on Intellij
End time: 16:05
Time taken: 1h05m

Trouble 2: 

Begin time: 16:30
description: HTML does not block incorrect inputs even with pattern variable on input tag
Solution: 1) Build function on Javacript to verify input
          2) Use regex 
End time: 17:30
Time taken: 1h


Trouble 3:
Begin time: 17:10
Description: +or - is not being recognized in the numbers input
Solution: parseFloat(input)
End time : 17:17
time taken: 7min

Trouble 4: 
Begin Time: 18:40
Description: Regex is not working
Solution: regex is-
		1) not surrounded by ""
                2) extra white spece are taking in account -> do not use "     \d+" for example

End time: 19:03
time taken: 23min

Trouble 5: 
Begin time: 20:43
Description: pproblem in setting div to wrap 
Solution: set max-width to a css class
          set word-wrap: break-word to css class

















