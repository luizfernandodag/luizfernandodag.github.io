Lab8 - Readme

Student: Luiz Fernando de Andrade Gadelha
Id:      610800

Exercise 1

Exercise 2

Exercise 3

Exercise 4




